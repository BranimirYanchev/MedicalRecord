async function loadDoctors() {
    const doctors = await apiGet("/doctor/all");
    const table = document.getElementById("doctorsTable");

    table.innerHTML = `
        <tr>
            <th>ID</th>
            <th>Име</th>
            <th>Специалност</th>
            <th>Личен лекар</th>
            <th>Действия</th>
        </tr>
    `;

    doctors.forEach(d => {
        const row = table.insertRow();
        row.insertCell(0).textContent = d.id;
        row.insertCell(1).textContent = d.name;
        row.insertCell(2).textContent = d.specialty;
        row.insertCell(3).textContent = d.personalDoctor ? "Да" : "Не";

        const btnDelete = document.createElement("button");
        btnDelete.textContent = "Изтрий";
        btnDelete.onclick = () => deleteDoctor(d.id);

        row.insertCell(4).appendChild(btnDelete);
    });
}

async function addDoctor() {
    const name = document.getElementById("dName").value;
    const specialty = document.getElementById("dSpec").value;
    const personalDoctor = document.getElementById("dPD").checked;

    if (!name || !specialty) {
        alert("Попълни всички полета!");
        return;
    }

    await apiPost("/doctor/add", { name, specialty, personalDoctor });
    loadDoctors();
}

async function deleteDoctor(id) {
    if (!confirm("Сигурен ли си?")) return;

    await apiDelete(`/doctor/delete/${id}`);
    loadDoctors();
}

window.onload = loadDoctors;
