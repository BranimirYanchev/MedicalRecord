// Зарежда dropdown + таблица
async function loadLeavesPage() {
    await loadVisits();
    await loadLeavesTable();
}

// Зарежда всички посещения
async function loadVisits() {
    const visits = await apiGet("/visit/all");
    const select = document.getElementById("lVisit");

    select.innerHTML = "";

    visits.forEach(v => {
        const opt = document.createElement("option");
        opt.value = v.id;
        opt.textContent = `Visit #${v.id} – ${v.patient?.name || "Пациент?"}`;
        select.appendChild(opt);
    });
}

// Таблица болнични
async function loadLeavesTable() {
    const leaves = await apiGet("/leave/all");
    const table = document.getElementById("leavesTable");

    table.innerHTML = `
        <tr>
            <th>ID</th>
            <th>Начало</th>
            <th>Дни</th>
            <th>Посещение</th>
            <th>Пациент</th>
        </tr>
    `;

    leaves.forEach(l => {
        const row = table.insertRow();
        row.insertCell(0).textContent = l.id;
        row.insertCell(1).textContent = l.startDate;
        row.insertCell(2).textContent = l.days;
        row.insertCell(3).textContent = l.visit ? l.visit.id : "—";
        row.insertCell(4).textContent = l.visit?.patient?.name || "—";
    });
}

// Добавяне
async function addLeave() {
    const visitId = document.getElementById("lVisit").value;
    const startDate = document.getElementById("lStart").value;
    const days = document.getElementById("lDays").value;

    if (!startDate || !days) {
        alert("Попълни начална дата и дни!");
        return;
    }

    await apiPost(`/leave/add?visitId=${visitId}`, {
        startDate,
        days
    });

    await loadLeavesTable();
}

window.onload = loadLeavesPage;
