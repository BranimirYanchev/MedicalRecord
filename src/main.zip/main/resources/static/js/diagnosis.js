// Зареждане на dropdown + таблица
async function loadDiagnosisPage() {
    await loadVisits();
    await loadDiagnosisTable();
}

// Зарежда всички посещения за dropdown
async function loadVisits() {
    const visits = await apiGet("/visit/all");
    const select = document.getElementById("dVisit");
    select.innerHTML = "";

    visits.forEach(v => {
        const opt = document.createElement("option");
        opt.value = v.id;
        opt.textContent = `Visit #${v.id} – ${v.patient?.name || "Пациент?"} при ${v.doctor?.name || "Лекар?"}`;
        select.appendChild(opt);
    });
}

// Зарежда таблицата с всички диагнози
async function loadDiagnosisTable() {
    const diagnosisList = await apiGet("/diagnosis/all");
    const table = document.getElementById("diagnosisTable");

    table.innerHTML = `
        <tr>
            <th>ID</th>
            <th>Диагноза</th>
            <th>Посещение</th>
            <th>Дата</th>
        </tr>
    `;

    diagnosisList.forEach(d => {
        const row = table.insertRow();
        row.insertCell(0).textContent = d.id;
        row.insertCell(1).textContent = d.text;
        row.insertCell(2).textContent = d.visit ? d.visit.id : "—";
        row.insertCell(3).textContent = d.visit ? d.visit.visitDate : "—";
    });
}

// Добавяне на диагноза
async function addDiagnosis() {
    const visitId = document.getElementById("dVisit").value;
    const text = document.getElementById("dText").value;

    if (!text) {
        alert("Моля, въведи име на диагноза.");
        return;
    }

    await apiPost(`/diagnosis/add?visitId=${visitId}`, {
        text
    });

    document.getElementById("dText").value = "";
    await loadDiagnosisTable();
}

window.onload = loadDiagnosisPage;
