// Зареждане на всички пациенти
async function loadPatients() {
    const patients = await apiGet("/patient/all");
    const doctors = await apiGet("/doctor/all");

    // Populate doctor dropdown for NEW patient
    const doctorSelect = document.getElementById("pDoctor");
    doctorSelect.innerHTML = "";
    doctors.forEach(d => {
        const opt = document.createElement("option");
        opt.value = d.id;
        opt.textContent = `${d.name} (${d.specialty})`;
        doctorSelect.appendChild(opt);
    });

    // Fill table
    const table = document.getElementById("patientsTable");
    table.innerHTML = `
        <tr>
            <th>ID</th>
            <th>Име</th>
            <th>ЕГН</th>
            <th>Личен лекар</th>
            <th>Осигуровки</th>
            <th></th>
        </tr>
    `;

    patients.forEach(p => {
        const row = table.insertRow();
        row.insertCell(0).textContent = p.id;
        row.insertCell(1).textContent = p.name;
        row.insertCell(2).textContent = p.egn;
        row.insertCell(3).textContent = p.personalDoctor ? p.personalDoctor.name : "—";
        row.insertCell(4).textContent = p.insurancePaid ? "Да" : "Не";

        // Delete button
        const delBtn = document.createElement("button");
        delBtn.classList.add("btn-danger");
        delBtn.textContent = "Изтрий";
        delBtn.onclick = () => deletePatient(p.id);

        row.insertCell(5).appendChild(delBtn);
    });
}

// Добавяне на пациент
async function addPatient() {
    const name = document.getElementById("pName").value;
    const egn = document.getElementById("pEGN").value;
    const insurancePaid = document.getElementById("pInsurance").checked;
    const doctorId = document.getElementById("pDoctor").value;

    if (!name || !egn) {
        alert("Попълни всички полета!");
        return;
    }

    await apiPost("/patient/add", {
        name,
        egn,
        insurancePaid,
        personalDoctorId: doctorId
    });

    loadPatients();
}

// Изтриване
async function deletePatient(id) {
    if (!confirm("Сигурен ли си?")) return;

    await apiDelete(`/patient/delete/${id}`);
    loadPatients();
}

window.onload = loadPatients;
