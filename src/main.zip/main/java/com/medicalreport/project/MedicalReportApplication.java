package com.medicalreport.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedicalReportApplication {
    public static void main(String[] args) {
        SpringApplication.run(MedicalReportApplication.class, args);
    }
}

