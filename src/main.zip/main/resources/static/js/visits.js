// Зареждане на лекари и пациенти за dropdown-ите + таблицата с посещения
async function loadVisitsPage() {
    await loadDoctorAndPatientOptions();
    await loadVisitsTable();
}

// Зарежда списъка с лекари и пациенти
async function loadDoctorAndPatientOptions() {
    const doctors = await apiGet("/doctor/all");
    const patients = await apiGet("/patient/all");

    const doctorSelect = document.getElementById("vDoctor");
    const patientSelect = document.getElementById("vPatient");

    doctorSelect.innerHTML = "";
    patientSelect.innerHTML = "";

    doctors.forEach(d => {
        const opt = document.createElement("option");
        opt.value = d.id;
        opt.textContent = `${d.name} (${d.specialty})`;
        doctorSelect.appendChild(opt);
    });

    patients.forEach(p => {
        const opt = document.createElement("option");
        opt.value = p.id;
        opt.textContent = `${p.name} – ЕГН: ${p.egn}`;
        patientSelect.appendChild(opt);
    });
}

// Зарежда таблицата с всички посещения
async function loadVisitsTable() {
    const visits = await apiGet("/visit/all");
    const table = document.getElementById("visitsTable");

    table.innerHTML = `
        <tr>
            <th>ID</th>
            <th>Дата</th>
            <th>Лекар</th>
            <th>Пациент</th>
        </tr>
    `;

    visits.forEach(v => {
        const row = table.insertRow();
        row.insertCell(0).textContent = v.id;
        row.insertCell(1).textContent = v.visitDate || "";
        row.insertCell(2).textContent = v.doctor ? v.doctor.name : "—";
        row.insertCell(3).textContent = v.patient ? v.patient.name : "—";
    });
}

// Добавяне на ново посещение
async function addVisit() {
    const doctorId = document.getElementById("vDoctor").value;
    const patientId = document.getElementById("vPatient").value;
    const date = document.getElementById("vDate").value;

    if (!doctorId || !patientId || !date) {
        alert("Моля, попълни лекар, пациент и дата.");
        return;
    }

    // backend: POST /visit/add?doctorId=...&patientId=...
    await apiPost(`/visit/add?doctorId=${doctorId}&patientId=${patientId}`, {
        visitDate: date
    });

    // рефреш на таблицата
    await loadVisitsTable();
}

// автоматично зареждане на страницата
window.onload = loadVisitsPage;
